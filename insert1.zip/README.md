# Expense-Tracker
A PHP and MySQL-based personal finance manager that allows users to track expenses, record amounts given or received, and manage financial history through a responsive web interface.
