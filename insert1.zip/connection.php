<?php
    $con=new mysqli('localhost','root','xEbx3xxl]9HTXOec','expense');
    if(!$con){
        die(mysqli_error($con));
    }
    